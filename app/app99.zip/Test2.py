from kivy.lang import Builder
from kivy.properties import NumericProperty, ColorProperty, StringProperty, ListProperty, DictProperty
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.screen import MDScreen
from kivy.metrics import dp
from kivy.uix.floatlayout import FloatLayout
from kivymd.app import MDApp
from kivymd.uix.bottomnavigation import MDBottomNavigation, MDBottomNavigationItem

class BadgeWidget(MDBoxLayout):
    text = StringProperty("0")
    bg_color = ColorProperty([1, 0, 0, 1])
    text_color = ColorProperty([1, 1, 1, 1])
    radius_value = ListProperty([dp(12), dp(12), dp(12), dp(12)])
    font_size = StringProperty("11sp")
    pos_hint = DictProperty({"center_x": 0.75, "center_y": 0.85})
    opacity_value = NumericProperty(1)
    
    def set_count(self, value):
        try:
            count = int(value)
            count = max(0, min(count, 100))
            self.text = "99+" if count > 99 else str(count)
            self.opacity_value = 1 if count > 0 else 0
        except ValueError:
            self.text = "0"
            self.opacity_value = 0

Builder.load_string('''
<BadgeWidget>:
    size_hint: None, None
    width: dp(22) if len(root.text) <= 2 else dp(32)
    height: dp(22)
    md_bg_color: root.bg_color
    radius: root.radius_value
    pos_hint: root.pos_hint
    opacity: root.opacity_value
    
    MDLabel:
        text: root.text
        halign: "center"
        valign: "center"
        font_style: "Caption"
        theme_text_color: "Custom"
        text_color: root.text_color
        font_size: root.font_size
        bold: True
        size_hint_x: None
        width: self.texture_size[0]

<CustomBottomNavItem>:
    size_hint_y: None
    height: dp(56)
    
    FloatLayout:
        MDIcon:
            icon: root.icon
            pos_hint: {"center_x": 0.5, "center_y": 0.6}
            theme_text_color: "Custom"
            text_color: root.text_color_normal if root.state == 'normal' else root.text_color_active
            font_size: "24sp"
        
        MDLabel:
            text: root.text
            halign: "center"
            size_hint_y: None
            height: dp(20)
            pos_hint: {"center_x": 0.5, "center_y": 0.2}
            theme_text_color: "Custom"
            text_color: root.text_color_normal if root.state == 'normal' else root.text_color_active
            font_size: "12sp"
        
        BadgeWidget:
            id: badge
            text: root.badge_text
            bg_color: root.badge_color
            opacity_value: 1 if root.badge_text != "0" else 0
            pos_hint: {"center_x": 0.7, "center_y": 0.7}
''')

class CustomBottomNavItem(MDBoxLayout):
    icon = StringProperty("home")
    text = StringProperty("")
    badge_text = StringProperty("0")
    badge_color = ColorProperty([1, 0, 0, 1])
    state = StringProperty("normal")
    text_color_normal = ColorProperty([0.5, 0.5, 0.5, 1])
    text_color_active = ColorProperty([0.2, 0.6, 1, 1])
    
    def set_badge(self, value):
        self.badge_text = str(value)
        if self.ids.badge:
            self.ids.badge.set_count(value)

class MainScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.current_tab = "home"
    
    def switch_tab(self, tab_name):
        self.current_tab = tab_name
        self.ids.screen_manager.current = tab_name
        
        # Update states
        for item in [self.ids.nav_home, self.ids.nav_cart, self.ids.nav_messages]:
            item.state = "normal"
        
        if tab_name == "home":
            self.ids.nav_home.state = "down"
        elif tab_name == "cart":
            self.ids.nav_cart.state = "down"
        elif tab_name == "messages":
            self.ids.nav_messages.state = "down"

KV = '''
MainScreen:
    BoxLayout:
        orientation: "vertical"
        
        ScreenManager:
            id: screen_manager
            
            Screen:
                name: "home"
                MDLabel:
                    text: "Home Page"
                    halign: "center"
                    font_style: "H4"
            
            Screen:
                name: "cart"
                MDLabel:
                    text: "Cart Page"
                    halign: "center"
                    font_style: "H4"
            
            Screen:
                name: "messages"
                MDLabel:
                    text: "Messages Page"
                    halign: "center"
                    font_style: "H4"
        
        MDSeparator:
        
        BoxLayout:
            size_hint_y: None
            height: dp(56)
            
            CustomBottomNavItem:
                id: nav_home
                icon: "home"
                text: "Home"
                badge_text: "42"
                badge_color: [1, 0, 0, 1]
                state: "down"
                on_touch_down:
                    if self.collide_point(*args[1].pos): root.switch_tab('home')
            
            CustomBottomNavItem:
                id: nav_cart
                icon: "cart"
                text: "Cart"
                badge_text: "5"
                badge_color: [0.2, 0.8, 0.2, 1]
                on_touch_down:
                    if self.collide_point(*args[1].pos): root.switch_tab('cart')
            
            CustomBottomNavItem:
                id: nav_messages
                icon: "message"
                text: "Messages"
                badge_text: "99+"
                badge_color: [1, 0.65, 0, 1]
                on_touch_down:
                    if self.collide_point(*args[1].pos): root.switch_tab('messages')
'''

class TestApp(MDApp):
    def build(self):
        return Builder.load_string(KV)

if __name__ == "__main__":
    TestApp().run()