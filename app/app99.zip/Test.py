from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.utils import platform
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
import os

KV = '''
MDFloatLayout:
    
    BoxLayout:
        orientation: 'vertical'
        size_hint: 0.9, 0.8
        pos_hint: {"center_x": 0.5, "center_y": 0.5}
        spacing: "20dp"
        padding: "20dp"
        
        MDLabel:
            text: "Upload File"
            halign: "center"
            font_style: "H4"
            size_hint_y: None
            height: self.texture_size[1]
        
        MDRaisedButton:
            id: btn_select
            text: "Select File"
            size_hint: 0.8, None
            height: "50dp"
            pos_hint: {"center_x": 0.5}
            on_release: app.select_file()
        
        MDCard:
            size_hint: 1, None
            height: "150dp"
            padding: "20dp"
            elevation: 2
            
            BoxLayout:
                orientation: 'vertical'
                spacing: "10dp"
                
                MDLabel:
                    id: lbl_file_name
                    text: "No file selected"
                    halign: "center"
                    theme_text_color: "Secondary"
                
                MDLabel:
                    id: lbl_file_size
                    text: ""
                    halign: "center"
                    theme_text_color: "Hint"
                    font_style: "Caption"
                
                MDLabel:
                    id: lbl_file_path
                    text: ""
                    halign: "center"
                    theme_text_color: "Hint"
                    font_style: "Caption"
                    text_size: self.width, None
        
        Widget:
            size_hint_y: 0.2
        
        MDRaisedButton:
            id: btn_upload
            text: "Upload File"
            size_hint: 0.8, None
            height: "50dp"
            pos_hint: {"center_x": 0.5}
            disabled: True
            on_release: app.upload_file()
'''

class FileUploadApp(MDApp):
    def build(self):
        self.theme_cls.primary_palette = "Teal"
        self.selected_file = None
        return Builder.load_string(KV)
    
    def select_file(self):
        '''Select file based on platform'''
        current_platform = platform
        
        if current_platform == 'android':
            self.select_file_android()
        elif current_platform in ['win', 'linux', 'macosx']:
            self.select_file_desktop()
        else:
            self.select_file_fallback()
    
    def select_file_android(self):
        '''Selection method for Android'''
        try:
            # Using MDFileManager for Android (simplest way)
            from kivymd.uix.filemanager import MDFileManager
            from kivymd.toast import toast
            
            self.file_manager = MDFileManager(
                exit_manager=self.exit_file_manager,
                select_path=self.on_file_selected,
                preview=False
            )
            
            # Starting path in Android
            try:
                from android.storage import primary_external_storage_path
                start_path = primary_external_storage_path()
            except:
                start_path = "/storage/emulated/0"
            
            self.file_manager.show(start_path)
            
        except Exception as e:
            print(f"Android file chooser error: {e}")
            self.select_file_fallback()
    
    def select_file_desktop(self):
        '''Selection method for Windows/Linux/Mac'''
        try:
            # Using tkinter (faster and better)
            import tkinter as tk
            from tkinter import filedialog
            
            root = tk.Tk()
            root.withdraw()  # Hide main window
            
            file_path = filedialog.askopenfilename(
                title="Select file to upload",
                filetypes=[
                    ("All files", "*.*"),
                    ("Images", "*.png *.jpg *.jpeg *.gif *.bmp"),
                    ("Documents", "*.pdf *.doc *.docx *.txt"),
                    ("Audio", "*.mp3 *.wav *.ogg"),
                    ("Video", "*.mp4 *.avi *.mkv *.mov"),
                ]
            )
            
            root.destroy()
            
            if file_path:
                self.on_file_selected(file_path)
                
        except ImportError:
            # Use fallback method if tkinter is not available
            self.select_file_fallback()
        except Exception as e:
            print(f"Desktop file chooser error: {e}")
            self.select_file_fallback()
    
    def select_file_fallback(self):
        '''Fallback method for all platforms'''
        try:
            from kivy.uix.filechooser import FileChooserListView
            from kivy.uix.popup import Popup
            from kivy.uix.boxlayout import BoxLayout
            from kivy.uix.button import Button
            
            # Create layout for popup
            layout = BoxLayout(orientation='vertical')
            
            # Create file chooser
            chooser = FileChooserListView(
                filters=['*.*'],
                multiselect=False
            )
            
            # Create buttons
            btn_layout = BoxLayout(size_hint_y=None, height=50)
            btn_cancel = Button(text="Cancel")
            btn_select = Button(text="Select", background_color=(0.2, 0.6, 0.8, 1))
            
            btn_layout.add_widget(btn_cancel)
            btn_layout.add_widget(btn_select)
            
            layout.add_widget(chooser)
            layout.add_widget(btn_layout)
            
            # Create popup
            popup = Popup(
                title='Select File',
                content=layout,
                size_hint=(0.9, 0.8)
            )
            
            # Define event handlers
            def select_file(instance):
                if chooser.selection:
                    file_path = chooser.selection[0]
                    self.on_file_selected(file_path)
                    popup.dismiss()
            
            def cancel(instance):
                popup.dismiss()
            
            btn_select.bind(on_release=select_file)
            btn_cancel.bind(on_release=cancel)
            
            popup.open()
            
        except Exception as e:
            self.show_error(f"File selection error: {str(e)}")
    
    def on_file_selected(self, file_path):
        '''When a file is selected'''
        if not os.path.exists(file_path):
            self.show_error("File does not exist!")
            return
        
        self.selected_file = file_path
        
        # Display file information
        file_name = os.path.basename(file_path)
        file_size = self.get_file_size(file_path)
        
        self.root.ids.lbl_file_name.text = f"File: {file_name}"
        self.root.ids.lbl_file_size.text = f"Size: {file_size}"
        self.root.ids.lbl_file_path.text = f"Path: {file_path}"
        
        # Enable upload button
        self.root.ids.btn_upload.disabled = False
        self.root.ids.btn_select.text = "Change File"
        
        # Show success message
        from kivymd.toast import toast
        toast(f"File {file_name} selected")
    
    def exit_file_manager(self, *args):
        '''Close file manager on Android'''
        if hasattr(self, 'file_manager'):
            self.file_manager.close()
    
    def upload_file(self):
        '''Upload selected file'''
        if not self.selected_file:
            self.show_error("Please select a file first")
            return
        
        # Show progress dialog
        self.progress_dialog = MDDialog(
            title="Uploading...",
            text="Please wait",
            type="simple",
            auto_dismiss=False
        )
        self.progress_dialog.open()
        
        # Simulate upload (you would put your actual upload code here)
        from kivy.clock import Clock
        
        def complete_upload(dt):
            self.progress_dialog.dismiss()
            
            # Show success
            file_name = os.path.basename(self.selected_file)
            self.dialog = MDDialog(
                title="Success",
                text=f"File {file_name} uploaded successfully",
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
            self.dialog.open()
        
        # Timer for simulation
        Clock.schedule_once(complete_upload, 2)
    
    def get_file_size(self, filepath):
        '''Calculate file size'''
        try:
            size_bytes = os.path.getsize(filepath)
            
            # Convert to appropriate unit
            units = ['B', 'KB', 'MB', 'GB']
            size = float(size_bytes)
            
            for unit in units:
                if size < 1024.0 or unit == units[-1]:
                    return f"{size:.1f} {unit}"
                size /= 1024.0
        except:
            return "Unknown"
    
    def show_error(self, message):
        '''Show error'''
        self.dialog = MDDialog(
            title="Error",
            text=message,
            buttons=[
                MDFlatButton(
                    text="OK",
                    on_release=lambda x: self.dialog.dismiss()
                )
            ]
        )
        self.dialog.open()

if __name__ == '__main__':
    FileUploadApp().run()